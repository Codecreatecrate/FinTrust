
  # Fintech App Development

  This is a code bundle for Fintech App Development. The original project is available at https://www.figma.com/design/uXvkB7wOv7l3NpK8fjJ5MS/Fintech-App-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  