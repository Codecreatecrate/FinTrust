import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Badge } from '@/app/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/app/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Textarea } from '@/app/components/ui/textarea';
import { Slider } from '@/app/components/ui/slider';
import { 
  UserPlus, 
  Shield, 
  ShieldCheck, 
  ShieldAlert,
  Car,
  Briefcase,
  Users,
  Globe,
  Store,
  Star
} from 'lucide-react';
import { toast } from 'sonner';

interface ContactsListProps {
  accessToken: string;
  contacts: any[];
  onUpdate: () => void;
}

const connectionSourceIcons: Record<string, any> = {
  'Rapido Ride': Car,
  'Uber Ride': Car,
  'LinkedIn': Briefcase,
  'Instagram': Users,
  'Online Business': Globe,
  'Shopping App': Store,
  'Workplace': Briefcase,
  'Other': Users,
};

export function ContactsList({ accessToken, contacts, onUpdate }: ContactsListProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedContact, setSelectedContact] = useState<any>(null);
  const [isTrustDialogOpen, setIsTrustDialogOpen] = useState(false);
  
  // Add contact form state
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [connectionSource, setConnectionSource] = useState('');
  const [connectionDate, setConnectionDate] = useState('');
  const [notes, setNotes] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Trust rating state
  const [trustRating, setTrustRating] = useState(50);

  const handleAddContact = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { projectId } = await import('/utils/supabase/info');
      const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-f1d67aba`;

      const response = await fetch(`${baseUrl}/contacts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          contactName,
          contactEmail,
          connectionSource,
          connectionDate,
          notes
        })
      });

      const data = await response.json();

      if (!response.ok) {
        toast.error(`Failed to add contact: ${data.error}`);
        return;
      }

      toast.success('Contact added successfully!');
      setIsAddDialogOpen(false);
      resetForm();
      onUpdate();
    } catch (error) {
      console.error('Error adding contact:', error);
      toast.error('Failed to add contact');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateTrustRating = async () => {
    if (!selectedContact) return;
    setIsLoading(true);

    try {
      const { projectId } = await import('/utils/supabase/info');
      const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-f1d67aba`;

      const response = await fetch(`${baseUrl}/contacts/${selectedContact.id}/trust`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ userTrustRating: trustRating })
      });

      const data = await response.json();

      if (!response.ok) {
        toast.error(`Failed to update trust rating: ${data.error}`);
        return;
      }

      toast.success('Trust rating updated!');
      setIsTrustDialogOpen(false);
      onUpdate();
    } catch (error) {
      console.error('Error updating trust rating:', error);
      toast.error('Failed to update trust rating');
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setContactName('');
    setContactEmail('');
    setConnectionSource('');
    setConnectionDate('');
    setNotes('');
  };

  const getTrustBadge = (contact: any) => {
    // Calculate approximate trust score
    let score = 0;
    if (contact.governmentVerified) score += 25;
    if (contact.inContacts) score += 15;
    score += (contact.userTrustRating / 100) * 20;
    score += Math.min((contact.transactionCount / 10) * 20, 20);
    score += contact.spamReports * -30;
    score = Math.max(0, Math.min(100, score));

    if (score >= 70) {
      return <Badge className="bg-green-500"><ShieldCheck className="w-3 h-3 mr-1" />High Trust</Badge>;
    } else if (score >= 40) {
      return <Badge className="bg-yellow-500"><Shield className="w-3 h-3 mr-1" />Medium Trust</Badge>;
    } else {
      return <Badge variant="destructive"><ShieldAlert className="w-3 h-3 mr-1" />Low Trust</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Contacts</h2>
          <p className="text-gray-500">Manage your trusted connections</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="w-4 h-4 mr-2" />
              Add Contact
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Contact</DialogTitle>
              <DialogDescription>
                Add connection details and source information
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddContact} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="contact-name">Name</Label>
                <Input
                  id="contact-name"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="John Doe"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contact-email">Email</Label>
                <Input
                  id="contact-email"
                  type="email"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  placeholder="john@example.com"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="connection-source">Connection Source</Label>
                <Select value={connectionSource} onValueChange={setConnectionSource} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Where did you connect?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Rapido Ride">Rapido Ride</SelectItem>
                    <SelectItem value="Uber Ride">Uber Ride</SelectItem>
                    <SelectItem value="LinkedIn">LinkedIn</SelectItem>
                    <SelectItem value="Instagram">Instagram</SelectItem>
                    <SelectItem value="Online Business">Online Business</SelectItem>
                    <SelectItem value="Shopping App">Shopping App</SelectItem>
                    <SelectItem value="Workplace">Workplace</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="connection-date">Connection Date</Label>
                <Input
                  id="connection-date"
                  type="date"
                  value={connectionDate}
                  onChange={(e) => setConnectionDate(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add any additional context..."
                  rows={3}
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'Adding...' : 'Add Contact'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {contacts.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No contacts yet</h3>
            <p className="text-gray-500 mb-4">Add your first contact to start making secure payments</p>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <UserPlus className="w-4 h-4 mr-2" />
              Add Contact
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {contacts.map((contact) => {
            const SourceIcon = connectionSourceIcons[contact.connectionSource] || Users;
            
            return (
              <Card key={contact.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                        <SourceIcon className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{contact.contactName}</CardTitle>
                        <CardDescription className="text-xs">{contact.contactEmail}</CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Trust Level:</span>
                    {getTrustBadge(contact)}
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <SourceIcon className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">{contact.connectionSource}</span>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Transactions:</span>
                    <span className="font-medium">{contact.transactionCount || 0}</span>
                  </div>

                  {contact.transactionCount > 0 && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">Total Value:</span>
                      <span className="font-medium">${contact.totalTransactionValue?.toFixed(2) || '0.00'}</span>
                    </div>
                  )}

                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full mt-2"
                    onClick={() => {
                      setSelectedContact(contact);
                      setTrustRating(contact.userTrustRating);
                      setIsTrustDialogOpen(true);
                    }}
                  >
                    <Star className="w-4 h-4 mr-2" />
                    Rate Trust
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Trust Rating Dialog */}
      <Dialog open={isTrustDialogOpen} onOpenChange={setIsTrustDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rate Trust Level</DialogTitle>
            <DialogDescription>
              Set your personal trust rating for {selectedContact?.contactName}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Your Trust Rating</Label>
                <Badge variant="outline">{trustRating}%</Badge>
              </div>
              <Slider
                value={[trustRating]}
                onValueChange={(value) => setTrustRating(value[0])}
                min={0}
                max={100}
                step={5}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>No Trust</span>
                <span>Medium</span>
                <span>High Trust</span>
              </div>
            </div>
            <Button onClick={handleUpdateTrustRating} className="w-full" disabled={isLoading}>
              {isLoading ? 'Updating...' : 'Update Trust Rating'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
