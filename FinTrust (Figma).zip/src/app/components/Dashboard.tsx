import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { ContactsList } from '@/app/components/ContactsList';
import { PaymentInterface } from '@/app/components/PaymentInterface';
import { SubAccountsManager } from '@/app/components/SubAccountsManager';
import { TransactionHistory } from '@/app/components/TransactionHistory';
import { AlertsPanel } from '@/app/components/AlertsPanel';
import { 
  Wallet, 
  Users, 
  TrendingUp, 
  Bell, 
  LogOut,
  Shield,
  Activity
} from 'lucide-react';
import { toast } from 'sonner';
import { 
  mockContacts, 
  mockTransactions, 
  mockSubAccounts, 
  mockAlerts 
} from '@/utils/mockData';

interface DashboardProps {
  accessToken: string;
  userId: string;
  onLogout: () => void;
}

export function Dashboard({ accessToken, userId, onLogout }: DashboardProps) {
  const [subAccounts, setSubAccounts] = useState<any[]>(mockSubAccounts);
  const [contacts, setContacts] = useState<any[]>(mockContacts);
  const [transactions, setTransactions] = useState<any[]>(mockTransactions);
  const [alerts, setAlerts] = useState<any[]>(mockAlerts.filter(a => !a.read));
  const [isLoading, setIsLoading] = useState(false);

  // Using mock data - no need to fetch
  useEffect(() => {
    // Simulate initial load
    setIsLoading(false);
  }, []);

  const refreshData = () => {
    // For now, just keep the mock data
    // In production, this would fetch from the server
    toast.success('Data refreshed');
  };

  const totalBalance = subAccounts.reduce((sum, acc) => sum + acc.balance, 0);
  const totalLimit = subAccounts.reduce((sum, acc) => sum + acc.limit, 0);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Activity className="w-8 h-8 animate-spin mx-auto mb-2 text-indigo-600" />
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">TrustPay</h1>
                <p className="text-xs text-gray-500">Secure Fintech</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {alerts.length > 0 && (
                <Badge variant="destructive" className="flex items-center gap-1">
                  <Bell className="w-3 h-3" />
                  {alerts.length}
                </Badge>
              )}
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
              <Wallet className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalBalance.toFixed(2)}</div>
              <Progress value={(totalBalance / totalLimit) * 100} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">
                ${totalLimit.toFixed(2)} total limit
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Contacts</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{contacts.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Verified connections
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Transactions</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{transactions.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Total completed
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Alerts */}
        {alerts.length > 0 && (
          <div className="mb-8">
            <AlertsPanel alerts={alerts} />
          </div>
        )}

        {/* Main Tabs */}
        <Tabs defaultValue="accounts" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
            <TabsTrigger value="accounts">Accounts</TabsTrigger>
            <TabsTrigger value="pay">Pay</TabsTrigger>
            <TabsTrigger value="contacts">Contacts</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="accounts" className="space-y-4">
            <SubAccountsManager 
              accessToken={accessToken}
              subAccounts={subAccounts}
              onUpdate={refreshData}
            />
          </TabsContent>

          <TabsContent value="pay" className="space-y-4">
            <PaymentInterface
              accessToken={accessToken}
              contacts={contacts}
              subAccounts={subAccounts}
              onPaymentComplete={refreshData}
            />
          </TabsContent>

          <TabsContent value="contacts" className="space-y-4">
            <ContactsList
              accessToken={accessToken}
              contacts={contacts}
              onUpdate={refreshData}
            />
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <TransactionHistory transactions={transactions} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}