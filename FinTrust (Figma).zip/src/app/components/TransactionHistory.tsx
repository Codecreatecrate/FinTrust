import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import { 
  ArrowUpRight, 
  Clock, 
  CheckCircle2,
  Zap,
  Receipt
} from 'lucide-react';
import { format } from 'date-fns';

interface TransactionHistoryProps {
  transactions: any[];
}

export function TransactionHistory({ transactions }: TransactionHistoryProps) {
  const sortedTransactions = [...transactions].sort((a, b) => {
    const dateA = new Date(a.date || a.createdAt);
    const dateB = new Date(b.date || b.createdAt);
    return dateB.getTime() - dateA.getTime();
  });

  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return 'Invalid date';
      }
      return format(date, 'PPp');
    } catch (error) {
      return 'Invalid date';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Transaction History</h2>
        <p className="text-gray-500">View all your payment activity</p>
      </div>

      {sortedTransactions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Receipt className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No transactions yet</h3>
            <p className="text-gray-500">Your payment history will appear here</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Transactions</CardTitle>
            <CardDescription>{sortedTransactions.length} total transactions</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-4">
                {sortedTransactions.map((transaction) => (
                  <div 
                    key={transaction.id}
                    className="flex items-start justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex gap-4 flex-1">
                      <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <ArrowUpRight className="w-5 h-5 text-indigo-600" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium truncate">{transaction.contactName}</h4>
                          {transaction.isPriority && (
                            <Badge variant="outline" className="flex items-center gap-1">
                              <Zap className="w-3 h-3" />
                              Priority
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex flex-col gap-1 text-sm text-gray-600">
                          <div className="flex items-center gap-2">
                            <span className="text-xs">From:</span>
                            <span className="font-medium">{transaction.subAccountName}</span>
                          </div>
                          
                          {transaction.notes && (
                            <p className="text-xs text-gray-500 line-clamp-1">
                              {transaction.notes}
                            </p>
                          )}
                          
                          <div className="flex items-center gap-2 text-xs text-gray-400">
                            <Clock className="w-3 h-3" />
                            {formatDate(transaction.date || transaction.createdAt)}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0 ml-4">
                      <div className="text-lg font-bold text-red-600">
                        -${transaction.amount?.toFixed(2) || '0.00'}
                      </div>
                      <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
                        <CheckCircle2 className="w-3 h-3 text-green-500" />
                        {transaction.status}
                      </div>
                      {transaction.trustScore !== undefined && (
                        <Badge 
                          variant={transaction.trustScore >= 70 ? 'default' : transaction.trustScore >= 40 ? 'secondary' : 'destructive'}
                          className="mt-1 text-xs"
                        >
                          Trust: {transaction.trustScore.toFixed(0)}%
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Summary Stats */}
      {sortedTransactions.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-sm text-gray-500">Total Spent</div>
              <div className="text-2xl font-bold text-red-600">
                ${sortedTransactions.reduce((sum, tx) => sum + (tx.amount || 0), 0).toFixed(2)}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="text-sm text-gray-500">Average Transaction</div>
              <div className="text-2xl font-bold">
                ${(sortedTransactions.reduce((sum, tx) => sum + (tx.amount || 0), 0) / sortedTransactions.length).toFixed(2)}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="text-sm text-gray-500">Priority Transactions</div>
              <div className="text-2xl font-bold">
                {sortedTransactions.filter(tx => tx.isPriority).length}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}