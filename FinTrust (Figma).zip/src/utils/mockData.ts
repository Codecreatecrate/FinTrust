// Mock data for TrustPay Fintech App

export interface Contact {
  id: string;
  name: string;
  email: string;
  phone: string;
  trustScore: number;
  connectionSource: string;
  connectionDate: string;
  governmentVerified: boolean;
  inContactList: boolean;
  transactionCount: number;
  spamReports: number;
  userRating: number;
  lastTransaction?: string;
  avatar?: string;
}

export interface Transaction {
  id: string;
  type: 'sent' | 'received';
  contactId: string;
  contactName: string;
  amount: number;
  subAccount: string;
  status: 'completed' | 'pending' | 'failed';
  date: string;
  description: string;
  trustScoreAtTime: number;
  priorityMode?: boolean;
}

export interface SubAccount {
  id: string;
  name: string;
  type: 'shopping' | 'savings' | 'investments' | 'donations' | 'entertainment';
  balance: number;
  limit: number;
  icon: string;
  color: string;
}

export interface Alert {
  id: string;
  type: 'warning' | 'error' | 'info' | 'success';
  title: string;
  message: string;
  date: string;
  read: boolean;
}

// Mock Contacts
export const mockContacts: Contact[] = [
  {
    id: 'c1',
    name: 'Sarah Johnson',
    email: 'sarah.j@email.com',
    phone: '+1 555-0101',
    trustScore: 95,
    connectionSource: 'LinkedIn - Professional Network',
    connectionDate: '2024-01-15',
    governmentVerified: true,
    inContactList: true,
    transactionCount: 24,
    spamReports: 0,
    userRating: 5,
    lastTransaction: '2026-01-10',
    avatar: 'SJ'
  },
  {
    id: 'c2',
    name: 'Michael Chen',
    email: 'mchen@business.com',
    phone: '+1 555-0102',
    trustScore: 88,
    connectionSource: 'Rapido Ride - Shared Trip on Dec 20, 2025',
    connectionDate: '2025-12-20',
    governmentVerified: true,
    inContactList: true,
    transactionCount: 8,
    spamReports: 0,
    userRating: 4.5,
    lastTransaction: '2025-12-28',
    avatar: 'MC'
  },
  {
    id: 'c3',
    name: 'Emily Rodriguez',
    email: 'emily.r@startup.io',
    phone: '+1 555-0103',
    trustScore: 92,
    connectionSource: 'Instagram - Mutual Friends (12)',
    connectionDate: '2024-06-10',
    governmentVerified: true,
    inContactList: true,
    transactionCount: 15,
    spamReports: 0,
    userRating: 5,
    lastTransaction: '2026-01-05',
    avatar: 'ER'
  },
  {
    id: 'c4',
    name: 'David Park',
    email: 'dpark@shop.com',
    phone: '+1 555-0104',
    trustScore: 76,
    connectionSource: 'Online Business - E-commerce Store',
    connectionDate: '2025-11-05',
    governmentVerified: false,
    inContactList: false,
    transactionCount: 3,
    spamReports: 0,
    userRating: 4,
    lastTransaction: '2025-12-15',
    avatar: 'DP'
  },
  {
    id: 'c5',
    name: 'Lisa Martinez',
    email: 'lisa.m@gmail.com',
    phone: '+1 555-0105',
    trustScore: 85,
    connectionSource: 'Facebook - Friend since 2019',
    connectionDate: '2024-03-20',
    governmentVerified: true,
    inContactList: true,
    transactionCount: 12,
    spamReports: 0,
    userRating: 4.5,
    lastTransaction: '2025-12-30',
    avatar: 'LM'
  },
  {
    id: 'c6',
    name: 'James Wilson',
    email: 'jwilson@tech.com',
    phone: '+1 555-0106',
    trustScore: 45,
    connectionSource: 'Online Marketplace - Product Purchase',
    connectionDate: '2025-12-28',
    governmentVerified: false,
    inContactList: false,
    transactionCount: 1,
    spamReports: 0,
    userRating: 3.5,
    avatar: 'JW'
  },
  {
    id: 'c7',
    name: 'Priya Sharma',
    email: 'priya.s@consulting.in',
    phone: '+91 98765-43210',
    trustScore: 98,
    connectionSource: 'Work Colleague - Same Office',
    connectionDate: '2023-08-15',
    governmentVerified: true,
    inContactList: true,
    transactionCount: 45,
    spamReports: 0,
    userRating: 5,
    lastTransaction: '2026-01-12',
    avatar: 'PS'
  },
  {
    id: 'c8',
    name: 'Carlos Santos',
    email: 'carlos@delivery.com',
    phone: '+1 555-0108',
    trustScore: 18,
    connectionSource: 'Unknown - First Time Contact',
    connectionDate: '2026-01-15',
    governmentVerified: false,
    inContactList: false,
    transactionCount: 0,
    spamReports: 1,
    userRating: 2,
    avatar: 'CS'
  },
  {
    id: 'c9',
    name: 'Aisha Khan',
    email: 'aisha.k@finance.com',
    phone: '+1 555-0109',
    trustScore: 91,
    connectionSource: 'LinkedIn - Professional Network',
    connectionDate: '2024-09-12',
    governmentVerified: true,
    inContactList: true,
    transactionCount: 18,
    spamReports: 0,
    userRating: 5,
    lastTransaction: '2026-01-08',
    avatar: 'AK'
  },
  {
    id: 'c10',
    name: 'Robert Taylor',
    email: 'rtaylor@service.com',
    phone: '+1 555-0110',
    trustScore: 67,
    connectionSource: 'Rapido Ride - Shared Trip on Jan 3, 2026',
    connectionDate: '2026-01-03',
    governmentVerified: false,
    inContactList: false,
    transactionCount: 2,
    spamReports: 0,
    userRating: 4,
    lastTransaction: '2026-01-10',
    avatar: 'RT'
  }
];

// Mock Transactions
export const mockTransactions: Transaction[] = [
  {
    id: 't1',
    type: 'sent',
    contactId: 'c7',
    contactName: 'Priya Sharma',
    amount: 150.00,
    subAccount: 'Shopping',
    status: 'completed',
    date: '2026-01-12T14:30:00Z',
    description: 'Lunch payment - Team outing',
    trustScoreAtTime: 98
  },
  {
    id: 't2',
    type: 'received',
    contactId: 'c1',
    contactName: 'Sarah Johnson',
    amount: 500.00,
    subAccount: 'Savings',
    status: 'completed',
    date: '2026-01-10T10:15:00Z',
    description: 'Freelance project payment',
    trustScoreAtTime: 95
  },
  {
    id: 't3',
    type: 'sent',
    contactId: 'c9',
    contactName: 'Aisha Khan',
    amount: 75.50,
    subAccount: 'Entertainment',
    status: 'completed',
    date: '2026-01-08T19:45:00Z',
    description: 'Concert tickets split',
    trustScoreAtTime: 91
  },
  {
    id: 't4',
    type: 'sent',
    contactId: 'c3',
    contactName: 'Emily Rodriguez',
    amount: 200.00,
    subAccount: 'Donations',
    status: 'completed',
    date: '2026-01-05T11:20:00Z',
    description: 'Charity fundraiser contribution',
    trustScoreAtTime: 92
  },
  {
    id: 't5',
    type: 'received',
    contactId: 'c2',
    contactName: 'Michael Chen',
    amount: 45.00,
    subAccount: 'Shopping',
    status: 'completed',
    date: '2025-12-28T16:30:00Z',
    description: 'Rapido ride share payment',
    trustScoreAtTime: 88
  },
  {
    id: 't6',
    type: 'sent',
    contactId: 'c5',
    contactName: 'Lisa Martinez',
    amount: 120.00,
    subAccount: 'Shopping',
    status: 'completed',
    date: '2025-12-30T13:10:00Z',
    description: 'Dinner bill split',
    trustScoreAtTime: 85
  },
  {
    id: 't7',
    type: 'sent',
    contactId: 'c4',
    contactName: 'David Park',
    amount: 350.00,
    subAccount: 'Shopping',
    status: 'completed',
    date: '2025-12-15T09:00:00Z',
    description: 'Online purchase - Electronics',
    trustScoreAtTime: 76
  },
  {
    id: 't8',
    type: 'sent',
    contactId: 'c10',
    contactName: 'Robert Taylor',
    amount: 25.00,
    subAccount: 'Shopping',
    status: 'completed',
    date: '2026-01-10T08:45:00Z',
    description: 'Rapido ride fare',
    trustScoreAtTime: 67
  },
  {
    id: 't9',
    type: 'received',
    contactId: 'c7',
    contactName: 'Priya Sharma',
    amount: 1000.00,
    subAccount: 'Investments',
    status: 'completed',
    date: '2025-12-20T15:30:00Z',
    description: 'Investment return - Joint venture',
    trustScoreAtTime: 98
  },
  {
    id: 't10',
    type: 'sent',
    contactId: 'c8',
    contactName: 'Carlos Santos',
    amount: 80.00,
    subAccount: 'Shopping',
    status: 'failed',
    date: '2026-01-15T12:00:00Z',
    description: 'Payment blocked - Trust score below threshold',
    trustScoreAtTime: 18,
    priorityMode: false
  },
  {
    id: 't11',
    type: 'sent',
    contactId: 'c1',
    contactName: 'Sarah Johnson',
    amount: 300.00,
    subAccount: 'Entertainment',
    status: 'pending',
    date: '2026-01-16T10:30:00Z',
    description: 'Weekend trip booking',
    trustScoreAtTime: 95
  },
  {
    id: 't12',
    type: 'received',
    contactId: 'c3',
    contactName: 'Emily Rodriguez',
    amount: 225.00,
    subAccount: 'Shopping',
    status: 'completed',
    date: '2025-12-05T14:20:00Z',
    description: 'Birthday gift contribution',
    trustScoreAtTime: 92
  }
].map(tx => ({
  ...tx,
  subAccountName: tx.subAccount,
  notes: tx.description,
  trustScore: tx.trustScoreAtTime,
  isPriority: tx.priorityMode || false
}));

// Mock Sub-Accounts
export const mockSubAccounts: SubAccount[] = [
  {
    id: 'sa1',
    name: 'Shopping',
    type: 'shopping',
    balance: 2450.75,
    limit: 5000,
    icon: '🛒',
    color: 'bg-blue-500'
  },
  {
    id: 'sa2',
    name: 'Savings',
    type: 'savings',
    balance: 8920.50,
    limit: 20000,
    icon: '💰',
    color: 'bg-green-500'
  },
  {
    id: 'sa3',
    name: 'Investments',
    type: 'investments',
    balance: 15340.00,
    limit: 50000,
    icon: '📈',
    color: 'bg-purple-500'
  },
  {
    id: 'sa4',
    name: 'Donations',
    type: 'donations',
    balance: 500.00,
    limit: 2000,
    icon: '❤️',
    color: 'bg-pink-500'
  },
  {
    id: 'sa5',
    name: 'Entertainment',
    type: 'entertainment',
    balance: 1250.25,
    limit: 3000,
    icon: '🎮',
    color: 'bg-orange-500'
  }
];

// Mock Alerts
export const mockAlerts: Alert[] = [
  {
    id: 'a1',
    type: 'warning',
    title: 'Low Trust Score Contact',
    message: 'Carlos Santos (Trust Score: 18%) attempted transaction. Payment blocked due to trust threshold.',
    date: '2026-01-15T12:00:00Z',
    read: false
  },
  {
    id: 'a2',
    type: 'info',
    title: 'New Contact Added',
    message: 'Robert Taylor added from Rapido ride on Jan 3. Trust Score: 67%',
    date: '2026-01-03T15:30:00Z',
    read: true
  },
  {
    id: 'a3',
    type: 'success',
    title: 'Trust Score Increased',
    message: 'Michael Chen\'s trust score increased to 88% after 8 successful transactions.',
    date: '2025-12-28T16:35:00Z',
    read: true
  },
  {
    id: 'a4',
    type: 'warning',
    title: 'Shopping Account Near Limit',
    message: 'Your Shopping sub-account has reached 49% of spending limit ($2,450.75 of $5,000).',
    date: '2026-01-12T14:35:00Z',
    read: false
  },
  {
    id: 'a5',
    type: 'info',
    title: 'Government Verification Complete',
    message: 'Priya Sharma\'s government ID verification completed successfully.',
    date: '2025-12-15T09:00:00Z',
    read: true
  },
  {
    id: 'a6',
    type: 'error',
    title: 'Transaction Failed',
    message: 'Payment to Carlos Santos failed. Contact does not meet minimum trust threshold (20%).',
    date: '2026-01-15T12:01:00Z',
    read: false
  },
  {
    id: 'a7',
    type: 'success',
    title: 'Large Payment Received',
    message: 'Received $1,000.00 from Priya Sharma to Investments account.',
    date: '2025-12-20T15:30:00Z',
    read: true
  }
];

// Helper function to get contact by ID
export const getContactById = (id: string): Contact | undefined => {
  return mockContacts.find(contact => contact.id === id);
};

// Helper function to get contacts above trust threshold
export const getContactsAboveThreshold = (threshold: number): Contact[] => {
  return mockContacts.filter(contact => contact.trustScore >= threshold);
};

// Helper function to get recent transactions
export const getRecentTransactions = (limit: number = 10): Transaction[] => {
  return mockTransactions
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, limit);
};

// Helper function to get unread alerts
export const getUnreadAlerts = (): Alert[] => {
  return mockAlerts.filter(alert => !alert.read);
};

// Calculate total balance across all sub-accounts
export const getTotalBalance = (): number => {
  return mockSubAccounts.reduce((total, account) => total + account.balance, 0);
};