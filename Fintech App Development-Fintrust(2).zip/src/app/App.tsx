import { useState, useEffect } from 'react';
import { supabase } from '@/utils/supabase-client';
import { AuthScreen } from '@/app/components/AuthScreen';
import { Dashboard } from '@/app/components/Dashboard';
import { Toaster } from '@/app/components/ui/sonner';

export default function App() {
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [isCheckingSession, setIsCheckingSession] = useState(true);

  useEffect(() => {
    checkExistingSession();
  }, []);

  const checkExistingSession = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        setAccessToken(session.access_token);
        setUserId(session.user.id);
      }
    } catch (error) {
      console.error('Error checking session:', error);
    } finally {
      setIsCheckingSession(false);
    }
  };

  const handleAuthSuccess = (token: string, id: string) => {
    setAccessToken(token);
    setUserId(id);
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      setAccessToken(null);
      setUserId(null);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  if (isCheckingSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      {accessToken && userId ? (
        <Dashboard 
          accessToken={accessToken} 
          userId={userId}
          onLogout={handleLogout}
        />
      ) : (
        <AuthScreen onAuthSuccess={handleAuthSuccess} />
      )}
      <Toaster />
    </>
  );
}