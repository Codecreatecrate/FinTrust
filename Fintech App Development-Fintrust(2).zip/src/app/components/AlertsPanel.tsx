import { Card, CardContent } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/app/components/ui/alert';
import { 
  AlertTriangle, 
  AlertCircle,
  Info,
  Wallet
} from 'lucide-react';

interface AlertsPanelProps {
  alerts: any[];
}

export function AlertsPanel({ alerts }: AlertsPanelProps) {
  const getAlertIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="h-4 w-4" />;
      case 'warning':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Info className="h-4 w-4" />;
    }
  };

  const getAlertVariant = (severity: string): "default" | "destructive" => {
    switch (severity) {
      case 'critical':
      case 'warning':
        return 'destructive';
      default:
        return 'default';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <AlertTriangle className="w-5 h-5 text-amber-600" />
        <h3 className="text-lg font-semibold">System Alerts</h3>
        <Badge variant="outline">{alerts.length}</Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {alerts.map((alert) => (
          <Alert key={alert.id} variant={getAlertVariant(alert.severity)}>
            <div className="flex items-start gap-3">
              {alert.type === 'low_balance' && <Wallet className="h-4 w-4 mt-0.5" />}
              {!alert.type && getAlertIcon(alert.severity)}
              <div className="flex-1">
                <AlertTitle className="text-sm font-medium capitalize">
                  {alert.type?.replace('_', ' ') || 'Alert'}
                </AlertTitle>
                <AlertDescription className="text-xs mt-1">
                  {alert.message}
                </AlertDescription>
              </div>
            </div>
          </Alert>
        ))}
      </div>
    </div>
  );
}
