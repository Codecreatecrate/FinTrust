import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Slider } from '@/app/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Switch } from '@/app/components/ui/switch';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { 
  Wallet, 
  TrendingUp, 
  Calendar,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Settings
} from 'lucide-react';
import { toast } from 'sonner';

interface AllocationRule {
  subAccountId: string;
  subAccountName: string;
  percentage: number;
  icon: string;
  color: string;
}

interface AllocationSettingsProps {
  subAccounts: any[];
  onUpdate: () => void;
}

export function AllocationSettings({ subAccounts, onUpdate }: AllocationSettingsProps) {
  const [isAutoAllocationEnabled, setIsAutoAllocationEnabled] = useState(true);
  const [allocationPeriod, setAllocationPeriod] = useState<'monthly' | 'weekly' | 'biweekly'>('monthly');
  const [expectedIncome, setExpectedIncome] = useState('5000');
  const [allocations, setAllocations] = useState<AllocationRule[]>(
    subAccounts.map(acc => ({
      subAccountId: acc.id,
      subAccountName: acc.name,
      percentage: acc.name === 'Savings' ? 30 : acc.name === 'Shopping' ? 40 : 10,
      icon: acc.icon,
      color: acc.color
    }))
  );
  const [nextAllocationDate, setNextAllocationDate] = useState('2026-02-01');

  const totalPercentage = allocations.reduce((sum, rule) => sum + rule.percentage, 0);
  const isValid = totalPercentage === 100;

  const handlePercentageChange = (subAccountId: string, newPercentage: number) => {
    setAllocations(prev => 
      prev.map(rule => 
        rule.subAccountId === subAccountId 
          ? { ...rule, percentage: Math.max(0, Math.min(100, newPercentage)) }
          : rule
      )
    );
  };

  const handleAutoBalance = () => {
    const equalPercentage = Math.floor(100 / allocations.length);
    const remainder = 100 - (equalPercentage * allocations.length);
    
    setAllocations(prev => 
      prev.map((rule, index) => ({
        ...rule,
        percentage: equalPercentage + (index === 0 ? remainder : 0)
      }))
    );
    toast.success('Allocations balanced equally');
  };

  const handleSaveAllocations = () => {
    if (!isValid) {
      toast.error('Total allocation must equal 100%');
      return;
    }
    
    toast.success('Allocation settings saved successfully!');
    onUpdate();
  };

  const handleRunAllocationNow = () => {
    if (!isValid) {
      toast.error('Cannot run allocation - total must equal 100%');
      return;
    }
    
    const income = parseFloat(expectedIncome);
    allocations.forEach(rule => {
      const amount = (income * rule.percentage) / 100;
      console.log(`Allocating $${amount.toFixed(2)} to ${rule.subAccountName}`);
    });
    
    toast.success(`Allocated $${expectedIncome} across all accounts!`);
    onUpdate();
  };

  const getNextAllocationText = () => {
    const periods = {
      monthly: 'Next Month',
      weekly: 'Next Week',
      biweekly: 'Next 2 Weeks'
    };
    return periods[allocationPeriod];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Settings className="w-6 h-6" />
          Auto-Allocation Settings
        </h2>
        <p className="text-gray-500">Automatically distribute income across your sub-accounts</p>
      </div>

      {/* Enable/Disable Auto Allocation */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Auto-Allocation</span>
            <Switch 
              checked={isAutoAllocationEnabled}
              onCheckedChange={setIsAutoAllocationEnabled}
            />
          </CardTitle>
          <CardDescription>
            Automatically allocate income when received based on predefined rules
          </CardDescription>
        </CardHeader>
        
        {isAutoAllocationEnabled && (
          <CardContent className="space-y-6">
            {/* Period Selection */}
            <div className="space-y-2">
              <Label>Allocation Period</Label>
              <Select value={allocationPeriod} onValueChange={(value: any) => setAllocationPeriod(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="biweekly">Bi-weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500">
                <Calendar className="w-3 h-3 inline mr-1" />
                Next allocation: {nextAllocationDate}
              </p>
            </div>

            {/* Expected Income */}
            <div className="space-y-2">
              <Label>Expected Income</Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    type="number"
                    value={expectedIncome}
                    onChange={(e) => setExpectedIncome(e.target.value)}
                    className="pl-7"
                    placeholder="5000"
                  />
                </div>
                <Button 
                  variant="outline" 
                  onClick={handleRunAllocationNow}
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Run Now
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Allocation Rules */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Allocation Rules</CardTitle>
              <CardDescription>Set percentage for each sub-account</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={handleAutoBalance}>
              Balance Equally
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Total Progress */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">Total Allocation</span>
              <div className="flex items-center gap-2">
                <span className={totalPercentage === 100 ? 'text-green-600' : 'text-red-600'}>
                  {totalPercentage}%
                </span>
                {isValid ? (
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-600" />
                )}
              </div>
            </div>
            <Progress value={totalPercentage} className="h-2" />
            {!isValid && (
              <p className="text-xs text-red-600">
                Total must equal 100% (currently {totalPercentage > 100 ? 'over' : 'under'} by {Math.abs(100 - totalPercentage)}%)
              </p>
            )}
          </div>

          {/* Individual Allocations */}
          <div className="space-y-4">
            {allocations.map((rule) => {
              const amount = (parseFloat(expectedIncome) * rule.percentage) / 100;
              return (
                <div key={rule.subAccountId} className="space-y-3 p-4 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 ${rule.color} rounded-lg flex items-center justify-center text-white text-lg`}>
                        {rule.icon}
                      </div>
                      <div>
                        <p className="font-medium">{rule.subAccountName}</p>
                        <p className="text-xs text-gray-500">
                          ${amount.toFixed(2)} per {allocationPeriod === 'monthly' ? 'month' : allocationPeriod === 'weekly' ? 'week' : '2 weeks'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Input
                        type="number"
                        value={rule.percentage}
                        onChange={(e) => handlePercentageChange(rule.subAccountId, parseInt(e.target.value) || 0)}
                        className="w-20 text-center"
                        min="0"
                        max="100"
                      />
                      <span className="text-sm font-medium">%</span>
                    </div>
                  </div>
                  <Slider
                    value={[rule.percentage]}
                    onValueChange={([value]) => handlePercentageChange(rule.subAccountId, value)}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
              );
            })}
          </div>

          {/* Preview */}
          {isValid && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-green-600 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-medium text-green-900 mb-2">Allocation Preview</h4>
                  <div className="space-y-1 text-sm">
                    <p className="text-green-700">
                      When you receive <span className="font-bold">${expectedIncome}</span>, it will be automatically distributed:
                    </p>
                    <ul className="list-disc list-inside space-y-1 text-green-700">
                      {allocations.map(rule => (
                        <li key={rule.subAccountId}>
                          {rule.icon} {rule.subAccountName}: <span className="font-bold">
                            ${((parseFloat(expectedIncome) * rule.percentage) / 100).toFixed(2)}
                          </span> ({rule.percentage}%)
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Save Button */}
          <Button 
            onClick={handleSaveAllocations} 
            className="w-full"
            disabled={!isValid}
          >
            <Wallet className="w-4 h-4 mr-2" />
            Save Allocation Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
