import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/app/components/ui/dialog';
import { Badge } from '@/app/components/ui/badge';
import { Switch } from '@/app/components/ui/switch';
import { 
  Smartphone, 
  Link2,
  Unlink,
  ShoppingCart,
  Coffee,
  ShoppingBag,
  Plane,
  Film,
  Plus,
  ExternalLink,
  CheckCircle2
} from 'lucide-react';
import { toast } from 'sonner';

interface LinkedApp {
  id: string;
  name: string;
  category: string;
  icon: any;
  linkedAccount: string;
  linkedAccountName: string;
  autoPayEnabled: boolean;
  lastUsed: string;
  color: string;
}

interface LinkedAppsManagerProps {
  subAccounts: any[];
  onUpdate: () => void;
}

const availableApps = [
  { id: 'amazon', name: 'Amazon', category: 'shopping', icon: ShoppingCart, color: 'bg-orange-500' },
  { id: 'uber', name: 'Uber', category: 'shopping', icon: Plane, color: 'bg-black' },
  { id: 'starbucks', name: 'Starbucks', category: 'entertainment', icon: Coffee, color: 'bg-green-600' },
  { id: 'netflix', name: 'Netflix', category: 'entertainment', icon: Film, color: 'bg-red-600' },
  { id: 'doordash', name: 'DoorDash', category: 'shopping', icon: ShoppingBag, color: 'bg-red-500' },
  { id: 'spotify', name: 'Spotify', category: 'entertainment', icon: Film, color: 'bg-green-500' }
];

const mockLinkedApps: LinkedApp[] = [
  {
    id: 'l1',
    name: 'Amazon',
    category: 'shopping',
    icon: ShoppingCart,
    linkedAccount: 'sa1',
    linkedAccountName: 'Shopping',
    autoPayEnabled: true,
    lastUsed: '2026-01-15',
    color: 'bg-orange-500'
  },
  {
    id: 'l2',
    name: 'Netflix',
    category: 'entertainment',
    icon: Film,
    linkedAccount: 'sa5',
    linkedAccountName: 'Entertainment',
    autoPayEnabled: true,
    lastUsed: '2026-01-10',
    color: 'bg-red-600'
  },
  {
    id: 'l3',
    name: 'Starbucks',
    category: 'entertainment',
    icon: Coffee,
    linkedAccount: 'sa5',
    linkedAccountName: 'Entertainment',
    autoPayEnabled: false,
    lastUsed: '2026-01-12',
    color: 'bg-green-600'
  }
];

export function LinkedAppsManager({ subAccounts, onUpdate }: LinkedAppsManagerProps) {
  const [linkedApps, setLinkedApps] = useState<LinkedApp[]>(mockLinkedApps);
  const [isLinkDialogOpen, setIsLinkDialogOpen] = useState(false);
  const [selectedApp, setSelectedApp] = useState<any>(null);
  const [selectedAccount, setSelectedAccount] = useState('');

  const handleLinkApp = () => {
    if (!selectedApp || !selectedAccount) {
      toast.error('Please select an app and account');
      return;
    }

    const account = subAccounts.find(acc => acc.id === selectedAccount);
    const newLinkedApp: LinkedApp = {
      id: `l${Date.now()}`,
      name: selectedApp.name,
      category: selectedApp.category,
      icon: selectedApp.icon,
      linkedAccount: selectedAccount,
      linkedAccountName: account?.name || '',
      autoPayEnabled: true,
      lastUsed: new Date().toISOString().split('T')[0],
      color: selectedApp.color
    };

    setLinkedApps([...linkedApps, newLinkedApp]);
    setIsLinkDialogOpen(false);
    setSelectedApp(null);
    setSelectedAccount('');
    toast.success(`${selectedApp.name} linked to ${account?.name}`);
    onUpdate();
  };

  const handleUnlinkApp = (appId: string) => {
    const app = linkedApps.find(a => a.id === appId);
    setLinkedApps(prev => prev.filter(a => a.id !== appId));
    toast.success(`${app?.name} unlinked`);
    onUpdate();
  };

  const handleToggleAutoPay = (appId: string) => {
    setLinkedApps(prev =>
      prev.map(app =>
        app.id === appId ? { ...app, autoPayEnabled: !app.autoPayEnabled } : app
      )
    );
    const app = linkedApps.find(a => a.id === appId);
    toast.success(`Auto-pay ${app?.autoPayEnabled ? 'disabled' : 'enabled'} for ${app?.name}`);
  };

  const appsByAccount = subAccounts.map(acc => ({
    account: acc,
    apps: linkedApps.filter(app => app.linkedAccount === acc.id)
  }));

  const unlinkedApps = availableApps.filter(
    app => !linkedApps.some(linked => linked.name === app.name)
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Smartphone className="w-6 h-6" />
            Linked Apps & Services
          </h2>
          <p className="text-gray-500">Connect your favorite apps to specific sub-accounts</p>
        </div>
        <Dialog open={isLinkDialogOpen} onOpenChange={setIsLinkDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Link App
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Link New App</DialogTitle>
              <DialogDescription>Connect an app or service to a sub-account</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Select App</Label>
                <div className="grid grid-cols-2 gap-2">
                  {unlinkedApps.map(app => (
                    <button
                      key={app.id}
                      onClick={() => setSelectedApp(app)}
                      className={`p-3 border rounded-lg flex items-center gap-3 hover:bg-gray-50 transition-colors ${
                        selectedApp?.id === app.id ? 'border-indigo-600 bg-indigo-50' : ''
                      }`}
                    >
                      <div className={`w-10 h-10 ${app.color} rounded-lg flex items-center justify-center text-white`}>
                        <app.icon className="w-5 h-5" />
                      </div>
                      <span className="font-medium text-sm">{app.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {selectedApp && (
                <div className="space-y-2">
                  <Label>Link to Account</Label>
                  <div className="grid grid-cols-1 gap-2">
                    {subAccounts.map(acc => (
                      <button
                        key={acc.id}
                        onClick={() => setSelectedAccount(acc.id)}
                        className={`p-3 border rounded-lg flex items-center justify-between hover:bg-gray-50 transition-colors ${
                          selectedAccount === acc.id ? 'border-indigo-600 bg-indigo-50' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 ${acc.color} rounded-lg flex items-center justify-center text-white text-lg`}>
                            {acc.icon}
                          </div>
                          <div className="text-left">
                            <p className="font-medium">{acc.name}</p>
                            <p className="text-xs text-gray-500">${acc.balance.toFixed(2)} available</p>
                          </div>
                        </div>
                        {selectedAccount === acc.id && (
                          <CheckCircle2 className="w-5 h-5 text-indigo-600" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsLinkDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleLinkApp} disabled={!selectedApp || !selectedAccount}>
                <Link2 className="w-4 h-4 mr-2" />
                Link App
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Connected Services</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Total Apps Linked</p>
              <p className="text-2xl font-bold">{linkedApps.length}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Auto-Pay Enabled</p>
              <p className="text-2xl font-bold">{linkedApps.filter(a => a.autoPayEnabled).length}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Apps by Account */}
      {appsByAccount.map(({ account, apps }) => (
        apps.length > 0 && (
          <Card key={account.id}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 ${account.color} rounded-lg flex items-center justify-center text-white text-lg`}>
                  {account.icon}
                </div>
                <div>
                  <CardTitle className="text-base">{account.name}</CardTitle>
                  <CardDescription>{apps.length} linked apps</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {apps.map(app => (
                  <div key={app.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center gap-3 flex-1">
                      <div className={`w-12 h-12 ${app.color} rounded-lg flex items-center justify-center text-white`}>
                        <app.icon className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{app.name}</p>
                          {app.autoPayEnabled && (
                            <Badge variant="default" className="text-xs">
                              Auto-Pay
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-gray-500">Last used: {app.lastUsed}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 ml-4">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-600">Auto-Pay</span>
                        <Switch
                          checked={app.autoPayEnabled}
                          onCheckedChange={() => handleToggleAutoPay(app.id)}
                        />
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleUnlinkApp(app.id)}
                      >
                        <Unlink className="w-4 h-4 text-red-600" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )
      ))}

      {linkedApps.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Smartphone className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No apps linked yet</h3>
            <p className="text-gray-500 mb-4">Connect your favorite apps to automatically use specific sub-accounts</p>
            <Button onClick={() => setIsLinkDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Link Your First App
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Benefits Info */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="space-y-2">
              <h4 className="font-medium text-blue-900">How Linked Apps Work</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Payments from linked apps automatically use the connected sub-account</li>
                <li>• Enable Auto-Pay to approve transactions automatically (within account limits)</li>
                <li>• Track spending per app across different categories</li>
                <li>• Unlink apps anytime without affecting your accounts</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
