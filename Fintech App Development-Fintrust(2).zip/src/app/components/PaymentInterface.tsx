import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Badge } from '@/app/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Textarea } from '@/app/components/ui/textarea';
import { Progress } from '@/app/components/ui/progress';
import { Switch } from '@/app/components/ui/switch';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/app/components/ui/alert-dialog';
import { 
  Send, 
  Shield, 
  ShieldAlert, 
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Zap
} from 'lucide-react';
import { toast } from 'sonner';

interface PaymentInterfaceProps {
  accessToken: string;
  contacts: any[];
  subAccounts: any[];
  onPaymentComplete: () => void;
}

export function PaymentInterface({ accessToken, contacts, subAccounts, onPaymentComplete }: PaymentInterfaceProps) {
  const [selectedContact, setSelectedContact] = useState('');
  const [selectedAccount, setSelectedAccount] = useState('');
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [isPriority, setIsPriority] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [trustScore, setTrustScore] = useState<number | null>(null);
  const [trustBreakdown, setTrustBreakdown] = useState<any>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [lowTrustWarning, setLowTrustWarning] = useState(false);

  const handleCheckTrust = async () => {
    if (!selectedContact) {
      toast.error('Please select a contact');
      return;
    }

    setIsLoading(true);
    try {
      const { projectId } = await import('/utils/supabase/info');
      const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-f1d67aba`;

      const response = await fetch(`${baseUrl}/trust-score/${selectedContact}`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });

      const data = await response.json();

      if (!response.ok) {
        toast.error(`Failed to check trust: ${data.error}`);
        return;
      }

      setTrustScore(data.trustScore);
      setTrustBreakdown(data.breakdown);

      if (data.trustScore < 20) {
        setLowTrustWarning(true);
      }
    } catch (error) {
      console.error('Error checking trust:', error);
      toast.error('Failed to check trust score');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePayment = async () => {
    if (!selectedContact || !selectedAccount || !amount) {
      toast.error('Please fill all required fields');
      return;
    }

    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    setShowConfirmDialog(true);
  };

  const confirmPayment = async () => {
    setIsLoading(true);
    setShowConfirmDialog(false);

    try {
      const { projectId } = await import('/utils/supabase/info');
      const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-f1d67aba`;

      const response = await fetch(`${baseUrl}/transactions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          contactId: selectedContact,
          subAccountId: selectedAccount,
          amount: parseFloat(amount),
          notes,
          isPriority
        })
      });

      const data = await response.json();

      if (!response.ok) {
        if (response.status === 403) {
          toast.error(`Payment blocked: ${data.error}`, {
            description: `Trust score: ${data.trustScore}% (minimum required: ${data.minRequired}%)`
          });
        } else {
          toast.error(`Payment failed: ${data.error}`);
        }
        return;
      }

      toast.success('Payment successful!', {
        description: `$${amount} sent. New balance: $${data.newBalance.toFixed(2)}`
      });

      // Reset form
      setSelectedContact('');
      setSelectedAccount('');
      setAmount('');
      setNotes('');
      setIsPriority(false);
      setTrustScore(null);
      setTrustBreakdown(null);
      setLowTrustWarning(false);

      onPaymentComplete();
    } catch (error) {
      console.error('Error processing payment:', error);
      toast.error('Payment failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const selectedContactData = contacts.find(c => c.id === selectedContact);
  const selectedAccountData = subAccounts.find(a => a.id === selectedAccount);

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            Make a Payment
          </CardTitle>
          <CardDescription>
            Send money with trust-based verification
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Contact Selection */}
          <div className="space-y-2">
            <Label htmlFor="contact">Recipient</Label>
            <Select value={selectedContact} onValueChange={setSelectedContact}>
              <SelectTrigger id="contact">
                <SelectValue placeholder="Select a contact" />
              </SelectTrigger>
              <SelectContent>
                {contacts.map((contact) => (
                  <SelectItem key={contact.id} value={contact.id}>
                    {contact.contactName} - {contact.connectionSource}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedContact && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleCheckTrust}
                disabled={isLoading}
                className="mt-2"
              >
                <Shield className="w-4 h-4 mr-2" />
                Check Trust Score
              </Button>
            )}
          </div>

          {/* Trust Score Display */}
          {trustScore !== null && (
            <Card className={`border-2 ${trustScore >= 70 ? 'border-green-500' : trustScore >= 40 ? 'border-yellow-500' : 'border-red-500'}`}>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Trust Score</span>
                    <div className="flex items-center gap-2">
                      {trustScore >= 70 ? (
                        <ShieldCheck className="w-5 h-5 text-green-500" />
                      ) : trustScore >= 40 ? (
                        <Shield className="w-5 h-5 text-yellow-500" />
                      ) : (
                        <ShieldAlert className="w-5 h-5 text-red-500" />
                      )}
                      <span className="text-2xl font-bold">{trustScore.toFixed(0)}%</span>
                    </div>
                  </div>
                  <Progress value={trustScore} className="h-2" />
                  
                  {trustBreakdown && (
                    <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Gov. Verified:</span>
                        <span className="font-medium">{trustBreakdown.governmentVerified}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">In Contacts:</span>
                        <span className="font-medium">{trustBreakdown.inContacts}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">TX History:</span>
                        <span className="font-medium">{trustBreakdown.transactionHistory?.toFixed(0)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">User Rating:</span>
                        <span className="font-medium">{trustBreakdown.userRating?.toFixed(0)}%</span>
                      </div>
                    </div>
                  )}

                  {lowTrustWarning && !isPriority && (
                    <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5" />
                      <div className="text-sm">
                        <p className="font-medium text-red-900">Low Trust Warning</p>
                        <p className="text-red-700">
                          This transaction will be blocked due to low trust score (&lt;20%). 
                          Enable Priority Mode to override.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Account Selection */}
          <div className="space-y-2">
            <Label htmlFor="account">Payment Account</Label>
            <Select value={selectedAccount} onValueChange={setSelectedAccount}>
              <SelectTrigger id="account">
                <SelectValue placeholder="Select a sub-account" />
              </SelectTrigger>
              <SelectContent>
                {subAccounts.map((account) => (
                  <SelectItem key={account.id} value={account.id}>
                    {account.name} - ${account.balance?.toFixed(2) || '0.00'}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedAccountData && (
              <p className="text-xs text-gray-500">
                Available: ${selectedAccountData.balance?.toFixed(2) || '0.00'} / 
                Limit: ${selectedAccountData.limit?.toFixed(2) || '0.00'} {selectedAccountData.period}
              </p>
            )}
          </div>

          {/* Amount */}
          <div className="space-y-2">
            <Label htmlFor="amount">Amount</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              min="0"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Payment description..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>

          {/* Priority Mode */}
          <div className="flex items-center justify-between p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start gap-3">
              <Zap className="w-5 h-5 text-amber-600 mt-0.5" />
              <div>
                <Label htmlFor="priority" className="text-sm font-medium cursor-pointer">
                  Priority Mode
                </Label>
                <p className="text-xs text-gray-600">
                  Override trust restrictions for urgent payments
                </p>
              </div>
            </div>
            <Switch
              id="priority"
              checked={isPriority}
              onCheckedChange={setIsPriority}
            />
          </div>

          {/* Submit Button */}
          <Button 
            onClick={handlePayment}
            disabled={isLoading || !selectedContact || !selectedAccount || !amount}
            className="w-full"
            size="lg"
          >
            {isLoading ? (
              'Processing...'
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Send Payment
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Payment</AlertDialogTitle>
            <AlertDialogDescription>
              Please review the payment details before confirming.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3 py-4">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Recipient:</span>
              <span className="font-medium">{selectedContactData?.contactName}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Account:</span>
              <span className="font-medium">{selectedAccountData?.name}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Amount:</span>
              <span className="font-medium text-lg">${amount}</span>
            </div>
            {trustScore !== null && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Trust Score:</span>
                <Badge variant={trustScore >= 70 ? 'default' : trustScore >= 40 ? 'secondary' : 'destructive'}>
                  {trustScore.toFixed(0)}%
                </Badge>
              </div>
            )}
            {isPriority && (
              <div className="flex items-center gap-2 p-2 bg-amber-50 border border-amber-200 rounded">
                <Zap className="w-4 h-4 text-amber-600" />
                <span className="text-xs text-amber-900">Priority Mode Enabled</span>
              </div>
            )}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmPayment}>
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Confirm Payment
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
