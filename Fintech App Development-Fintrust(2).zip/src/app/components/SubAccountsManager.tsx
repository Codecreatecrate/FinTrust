import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/app/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { 
  Wallet, 
  Plus, 
  ArrowRightLeft,
  DollarSign,
  ShoppingBag,
  PiggyBank,
  TrendingUp,
  Heart,
  Gamepad2
} from 'lucide-react';
import { toast } from 'sonner';

interface SubAccountsManagerProps {
  accessToken: string;
  subAccounts: any[];
  onUpdate: () => void;
}

const categoryIcons: Record<string, any> = {
  shopping: ShoppingBag,
  savings: PiggyBank,
  investment: TrendingUp,
  donation: Heart,
  entertainment: Gamepad2,
  default: Wallet,
};

const categoryColors: Record<string, string> = {
  shopping: 'bg-blue-500',
  savings: 'bg-green-500',
  investment: 'bg-purple-500',
  donation: 'bg-pink-500',
  entertainment: 'bg-orange-500',
  default: 'bg-gray-500',
};

export function SubAccountsManager({ accessToken, subAccounts, onUpdate }: SubAccountsManagerProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false);
  const [isAddFundsDialogOpen, setIsAddFundsDialogOpen] = useState(false);
  const [selectedAccountForFunds, setSelectedAccountForFunds] = useState('');
  
  // Add account form
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [limit, setLimit] = useState('');
  const [period, setPeriod] = useState('monthly');
  
  // Transfer form
  const [fromAccount, setFromAccount] = useState('');
  const [toAccount, setToAccount] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  
  // Add funds form
  const [fundsAmount, setFundsAmount] = useState('');
  
  const [isLoading, setIsLoading] = useState(false);

  const handleAddAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { projectId } = await import('/utils/supabase/info');
      const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-f1d67aba`;

      const response = await fetch(`${baseUrl}/sub-accounts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          name,
          category,
          balance: 0,
          limit: parseFloat(limit),
          period
        })
      });

      const data = await response.json();

      if (!response.ok) {
        toast.error(`Failed to create account: ${data.error}`);
        return;
      }

      toast.success('Sub-account created successfully!');
      setIsAddDialogOpen(false);
      resetAddForm();
      onUpdate();
    } catch (error) {
      console.error('Error creating sub-account:', error);
      toast.error('Failed to create sub-account');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { projectId } = await import('/utils/supabase/info');
      const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-f1d67aba`;

      const response = await fetch(`${baseUrl}/sub-accounts/transfer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          fromAccountId: fromAccount,
          toAccountId: toAccount,
          amount: parseFloat(transferAmount)
        })
      });

      const data = await response.json();

      if (!response.ok) {
        toast.error(`Transfer failed: ${data.error}`);
        return;
      }

      toast.success('Transfer completed successfully!');
      setIsTransferDialogOpen(false);
      resetTransferForm();
      onUpdate();
    } catch (error) {
      console.error('Error transferring funds:', error);
      toast.error('Transfer failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddFunds = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { projectId } = await import('/utils/supabase/info');
      const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-f1d67aba`;

      const response = await fetch(`${baseUrl}/sub-accounts/${selectedAccountForFunds}/add-funds`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          amount: parseFloat(fundsAmount)
        })
      });

      const data = await response.json();

      if (!response.ok) {
        toast.error(`Failed to add funds: ${data.error}`);
        return;
      }

      toast.success('Funds added successfully!');
      setIsAddFundsDialogOpen(false);
      setFundsAmount('');
      setSelectedAccountForFunds('');
      onUpdate();
    } catch (error) {
      console.error('Error adding funds:', error);
      toast.error('Failed to add funds');
    } finally {
      setIsLoading(false);
    }
  };

  const resetAddForm = () => {
    setName('');
    setCategory('');
    setLimit('');
    setPeriod('monthly');
  };

  const resetTransferForm = () => {
    setFromAccount('');
    setToAccount('');
    setTransferAmount('');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Sub-Accounts</h2>
          <p className="text-gray-500">Manage segregated funds for different purposes</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isTransferDialogOpen} onOpenChange={setIsTransferDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <ArrowRightLeft className="w-4 h-4 mr-2" />
                Transfer
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Transfer Between Accounts</DialogTitle>
                <DialogDescription>Move funds between your sub-accounts</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleTransfer} className="space-y-4">
                <div className="space-y-2">
                  <Label>From Account</Label>
                  <Select value={fromAccount} onValueChange={setFromAccount} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select source account" />
                    </SelectTrigger>
                    <SelectContent>
                      {subAccounts.map((account) => (
                        <SelectItem key={account.id} value={account.id}>
                          {account.name} - ${account.balance?.toFixed(2) || '0.00'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>To Account</Label>
                  <Select value={toAccount} onValueChange={setToAccount} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select destination account" />
                    </SelectTrigger>
                    <SelectContent>
                      {subAccounts.filter(a => a.id !== fromAccount).map((account) => (
                        <SelectItem key={account.id} value={account.id}>
                          {account.name} - ${account.balance?.toFixed(2) || '0.00'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Amount</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Transferring...' : 'Transfer Funds'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Account
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Sub-Account</DialogTitle>
                <DialogDescription>Set up a new segregated account</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleAddAccount} className="space-y-4">
                <div className="space-y-2">
                  <Label>Account Name</Label>
                  <Input
                    placeholder="e.g., Gaming Budget"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={category} onValueChange={setCategory} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="shopping">Shopping</SelectItem>
                      <SelectItem value="savings">Savings</SelectItem>
                      <SelectItem value="investment">Investment</SelectItem>
                      <SelectItem value="donation">Donation</SelectItem>
                      <SelectItem value="entertainment">Entertainment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Spending Limit</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="1000.00"
                    value={limit}
                    onChange={(e) => setLimit(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Period</Label>
                  <Select value={period} onValueChange={setPeriod}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Creating...' : 'Create Account'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {subAccounts.map((account) => {
          const Icon = categoryIcons[account.category] || categoryIcons.default;
          const colorClass = categoryColors[account.category] || categoryColors.default;
          const usagePercent = (account.balance / account.limit) * 100;

          return (
            <Card key={account.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 ${colorClass} rounded-full flex items-center justify-center`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{account.name}</CardTitle>
                      <CardDescription className="text-xs capitalize">{account.category}</CardDescription>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {account.period}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-baseline justify-between mb-2">
                    <span className="text-2xl font-bold">${account.balance?.toFixed(2) || '0.00'}</span>
                    <span className="text-sm text-gray-500">/ ${account.limit?.toFixed(2) || '0.00'}</span>
                  </div>
                  <Progress value={usagePercent} className="h-2" />
                  <p className="text-xs text-gray-500 mt-1">
                    {usagePercent.toFixed(0)}% of limit
                  </p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => {
                    setSelectedAccountForFunds(account.id);
                    setIsAddFundsDialogOpen(true);
                  }}
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Add Funds
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Add Funds Dialog */}
      <Dialog open={isAddFundsDialogOpen} onOpenChange={setIsAddFundsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Funds</DialogTitle>
            <DialogDescription>
              Add money to {subAccounts.find(a => a.id === selectedAccountForFunds)?.name}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddFunds} className="space-y-4">
            <div className="space-y-2">
              <Label>Amount</Label>
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={fundsAmount}
                onChange={(e) => setFundsAmount(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? 'Adding...' : 'Add Funds'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
