import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/app/components/ui/dialog';
import { Badge } from '@/app/components/ui/badge';
import { 
  Gift, 
  Ticket, 
  ArrowRightLeft,
  Plus,
  ExternalLink,
  Trash2,
  QrCode
} from 'lucide-react';
import { toast } from 'sonner';

interface Voucher {
  id: string;
  name: string;
  code: string;
  amount: number;
  type: 'gift_card' | 'voucher' | 'coupon';
  linkedAccount: string;
  linkedAccountName: string;
  expiryDate: string;
  provider: string;
  isActive: boolean;
}

interface VoucherManagerProps {
  subAccounts: any[];
  onUpdate: () => void;
}

const mockVouchers: Voucher[] = [
  {
    id: 'v1',
    name: 'Amazon Gift Card',
    code: 'AMZN-5678-9012',
    amount: 50.00,
    type: 'gift_card',
    linkedAccount: 'sa1',
    linkedAccountName: 'Shopping',
    expiryDate: '2026-12-31',
    provider: 'Amazon',
    isActive: true
  },
  {
    id: 'v2',
    name: 'Starbucks Voucher',
    code: 'SBUX-3456-7890',
    amount: 25.00,
    type: 'voucher',
    linkedAccount: 'sa5',
    linkedAccountName: 'Entertainment',
    expiryDate: '2026-06-30',
    provider: 'Starbucks',
    isActive: true
  },
  {
    id: 'v3',
    name: 'Netflix Gift Card',
    code: 'NFLX-1234-5678',
    amount: 100.00,
    type: 'gift_card',
    linkedAccount: 'sa5',
    linkedAccountName: 'Entertainment',
    expiryDate: '2027-01-31',
    provider: 'Netflix',
    isActive: true
  }
];

export function VoucherManager({ subAccounts, onUpdate }: VoucherManagerProps) {
  const [vouchers, setVouchers] = useState<Voucher[]>(mockVouchers);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false);
  const [selectedVoucher, setSelectedVoucher] = useState<Voucher | null>(null);
  
  // Add new voucher form
  const [newVoucher, setNewVoucher] = useState({
    name: '',
    code: '',
    amount: '',
    type: 'gift_card' as 'gift_card' | 'voucher' | 'coupon',
    linkedAccount: '',
    provider: '',
    expiryDate: ''
  });

  // Transfer form
  const [transferToAccount, setTransferToAccount] = useState('');

  const handleAddVoucher = () => {
    if (!newVoucher.name || !newVoucher.amount || !newVoucher.linkedAccount) {
      toast.error('Please fill all required fields');
      return;
    }

    const account = subAccounts.find(acc => acc.id === newVoucher.linkedAccount);
    const voucher: Voucher = {
      id: `v${Date.now()}`,
      name: newVoucher.name,
      code: newVoucher.code || `CODE-${Math.random().toString(36).substring(7).toUpperCase()}`,
      amount: parseFloat(newVoucher.amount),
      type: newVoucher.type,
      linkedAccount: newVoucher.linkedAccount,
      linkedAccountName: account?.name || '',
      expiryDate: newVoucher.expiryDate || '2027-12-31',
      provider: newVoucher.provider || 'Generic',
      isActive: true
    };

    setVouchers([...vouchers, voucher]);
    setIsAddDialogOpen(false);
    setNewVoucher({
      name: '',
      code: '',
      amount: '',
      type: 'gift_card',
      linkedAccount: '',
      provider: '',
      expiryDate: ''
    });
    toast.success(`Added ${voucher.name} to ${account?.name}`);
    onUpdate();
  };

  const handleTransferVoucher = () => {
    if (!selectedVoucher || !transferToAccount) {
      toast.error('Please select a destination account');
      return;
    }

    const toAccount = subAccounts.find(acc => acc.id === transferToAccount);
    
    setVouchers(prev => 
      prev.map(v => 
        v.id === selectedVoucher.id 
          ? { ...v, linkedAccount: transferToAccount, linkedAccountName: toAccount?.name || '' }
          : v
      )
    );

    toast.success(`Transferred ${selectedVoucher.name} to ${toAccount?.name}`);
    setIsTransferDialogOpen(false);
    setSelectedVoucher(null);
    setTransferToAccount('');
    onUpdate();
  };

  const handleDeleteVoucher = (voucherId: string) => {
    const voucher = vouchers.find(v => v.id === voucherId);
    setVouchers(prev => prev.filter(v => v.id !== voucherId));
    toast.success(`Deleted ${voucher?.name}`);
    onUpdate();
  };

  const getVoucherIcon = (type: string) => {
    switch (type) {
      case 'gift_card': return <Gift className="w-4 h-4" />;
      case 'voucher': return <Ticket className="w-4 h-4" />;
      case 'coupon': return <QrCode className="w-4 h-4" />;
      default: return <Gift className="w-4 h-4" />;
    }
  };

  const totalVoucherValue = vouchers.reduce((sum, v) => sum + v.amount, 0);
  const vouchersByAccount = subAccounts.map(acc => ({
    account: acc,
    vouchers: vouchers.filter(v => v.linkedAccount === acc.id),
    total: vouchers.filter(v => v.linkedAccount === acc.id).reduce((sum, v) => sum + v.amount, 0)
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Gift className="w-6 h-6" />
            Vouchers & Gift Cards
          </h2>
          <p className="text-gray-500">Manage your vouchers across sub-accounts</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Voucher
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Voucher</DialogTitle>
              <DialogDescription>Add a gift card or voucher to one of your sub-accounts</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Voucher Name *</Label>
                <Input
                  value={newVoucher.name}
                  onChange={(e) => setNewVoucher({ ...newVoucher, name: e.target.value })}
                  placeholder="Amazon Gift Card"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Type</Label>
                <Select value={newVoucher.type} onValueChange={(value: any) => setNewVoucher({ ...newVoucher, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gift_card">Gift Card</SelectItem>
                    <SelectItem value="voucher">Voucher</SelectItem>
                    <SelectItem value="coupon">Coupon</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Amount *</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    type="number"
                    value={newVoucher.amount}
                    onChange={(e) => setNewVoucher({ ...newVoucher, amount: e.target.value })}
                    placeholder="50.00"
                    className="pl-7"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Link to Account *</Label>
                <Select value={newVoucher.linkedAccount} onValueChange={(value) => setNewVoucher({ ...newVoucher, linkedAccount: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select account" />
                  </SelectTrigger>
                  <SelectContent>
                    {subAccounts.map(acc => (
                      <SelectItem key={acc.id} value={acc.id}>
                        {acc.icon} {acc.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Code (Optional)</Label>
                <Input
                  value={newVoucher.code}
                  onChange={(e) => setNewVoucher({ ...newVoucher, code: e.target.value })}
                  placeholder="XXXX-XXXX-XXXX"
                />
              </div>

              <div className="space-y-2">
                <Label>Provider</Label>
                <Input
                  value={newVoucher.provider}
                  onChange={(e) => setNewVoucher({ ...newVoucher, provider: e.target.value })}
                  placeholder="Amazon, Starbucks, etc."
                />
              </div>

              <div className="space-y-2">
                <Label>Expiry Date</Label>
                <Input
                  type="date"
                  value={newVoucher.expiryDate}
                  onChange={(e) => setNewVoucher({ ...newVoucher, expiryDate: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleAddVoucher}>Add Voucher</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Total Vouchers</p>
              <p className="text-2xl font-bold">{vouchers.length}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Value</p>
              <p className="text-2xl font-bold">${totalVoucherValue.toFixed(2)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Vouchers by Account */}
      {vouchersByAccount.map(({ account, vouchers: accountVouchers, total }) => (
        accountVouchers.length > 0 && (
          <Card key={account.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 ${account.color} rounded-lg flex items-center justify-center text-white text-lg`}>
                    {account.icon}
                  </div>
                  <div>
                    <CardTitle className="text-base">{account.name}</CardTitle>
                    <CardDescription>{accountVouchers.length} vouchers • ${total.toFixed(2)}</CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {accountVouchers.map(voucher => (
                  <div key={voucher.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-white">
                        {getVoucherIcon(voucher.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{voucher.name}</p>
                          <Badge variant="outline" className="text-xs">
                            {voucher.provider}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-500">Code: {voucher.code}</p>
                        <p className="text-xs text-gray-400">Expires: {voucher.expiryDate}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-green-600">${voucher.amount.toFixed(2)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <Dialog open={isTransferDialogOpen && selectedVoucher?.id === voucher.id} 
                              onOpenChange={(open) => {
                                setIsTransferDialogOpen(open);
                                if (!open) setSelectedVoucher(null);
                              }}>
                        <DialogTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => setSelectedVoucher(voucher)}
                          >
                            <ArrowRightLeft className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Transfer Voucher</DialogTitle>
                            <DialogDescription>
                              Move {voucher.name} to another sub-account
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div className="p-3 bg-gray-50 rounded-lg">
                              <p className="text-sm text-gray-600">Current Account</p>
                              <p className="font-medium">{account.icon} {account.name}</p>
                            </div>
                            <div className="space-y-2">
                              <Label>Transfer To</Label>
                              <Select value={transferToAccount} onValueChange={setTransferToAccount}>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select destination account" />
                                </SelectTrigger>
                                <SelectContent>
                                  {subAccounts
                                    .filter(acc => acc.id !== voucher.linkedAccount)
                                    .map(acc => (
                                      <SelectItem key={acc.id} value={acc.id}>
                                        {acc.icon} {acc.name}
                                      </SelectItem>
                                    ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button variant="outline" onClick={() => {
                              setIsTransferDialogOpen(false);
                              setSelectedVoucher(null);
                            }}>
                              Cancel
                            </Button>
                            <Button onClick={handleTransferVoucher}>
                              <ArrowRightLeft className="w-4 h-4 mr-2" />
                              Transfer
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleDeleteVoucher(voucher.id)}
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )
      ))}

      {vouchers.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Gift className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No vouchers yet</h3>
            <p className="text-gray-500 mb-4">Add gift cards and vouchers to organize them across your accounts</p>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Voucher
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
