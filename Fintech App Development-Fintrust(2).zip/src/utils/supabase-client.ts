import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '/utils/supabase/info';

// Singleton instance
let instance: SupabaseClient | null = null;

// Get or create the single Supabase client instance
export function getSupabaseClient(): SupabaseClient {
  if (!instance) {
    instance = createClient(
      `https://${projectId}.supabase.co`,
      publicAnonKey
    );
  }
  return instance;
}

// Export the singleton instance
export const supabase = getSupabaseClient();