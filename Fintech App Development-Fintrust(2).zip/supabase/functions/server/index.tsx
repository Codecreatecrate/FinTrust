import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Create Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-f1d67aba/health", (c) => {
  return c.json({ status: "ok" });
});

// ==================== AUTH ROUTES ====================

// Sign up
app.post("/make-server-f1d67aba/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`Signup error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    // Initialize user profile in KV store
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email,
      name,
      createdAt: new Date().toISOString(),
      governmentVerified: false,
      spamReports: 0,
      profession: '',
      workplace: '',
    });

    // Initialize default sub-accounts
    const defaultAccounts = [
      { name: 'Shopping', category: 'shopping', balance: 0, limit: 1000, period: 'monthly' },
      { name: 'Savings', category: 'savings', balance: 0, limit: 5000, period: 'monthly' },
      { name: 'Entertainment', category: 'entertainment', balance: 0, limit: 500, period: 'monthly' },
      { name: 'Social Service', category: 'donation', balance: 0, limit: 300, period: 'monthly' },
      { name: 'Investments', category: 'investment', balance: 0, limit: 2000, period: 'monthly' },
    ];

    for (const account of defaultAccounts) {
      const accountId = crypto.randomUUID();
      await kv.set(`subaccount:${data.user.id}:${accountId}`, {
        id: accountId,
        userId: data.user.id,
        ...account,
        createdAt: new Date().toISOString(),
      });
    }

    return c.json({ user: data.user });
  } catch (error) {
    console.log(`Signup error while processing request: ${error}`);
    return c.json({ error: 'Failed to create user' }, 500);
  }
});

// Login (handled by Supabase on frontend)
app.post("/make-server-f1d67aba/login", async (c) => {
  return c.json({ message: 'Use Supabase client for login' });
});

// ==================== CONTACT ROUTES ====================

// Get all contacts for a user
app.get("/make-server-f1d67aba/contacts", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const contacts = await kv.getByPrefix(`contact:${user.id}:`);
    return c.json({ contacts });
  } catch (error) {
    console.log(`Error fetching contacts: ${error}`);
    return c.json({ error: 'Failed to fetch contacts' }, 500);
  }
});

// Add a new contact
app.post("/make-server-f1d67aba/contacts", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { contactName, contactEmail, connectionSource, connectionDate, notes } = await c.req.json();
    const contactId = crypto.randomUUID();

    const contactData = {
      id: contactId,
      userId: user.id,
      contactName,
      contactEmail,
      connectionSource, // e.g., "Rapido Ride", "Instagram", "LinkedIn"
      connectionDate,
      notes,
      createdAt: new Date().toISOString(),
      transactionCount: 0,
      totalTransactionValue: 0,
      spamReports: 0,
      userTrustRating: 50, // default
      inContacts: false,
      governmentVerified: false,
    };

    await kv.set(`contact:${user.id}:${contactId}`, contactData);
    return c.json({ contact: contactData });
  } catch (error) {
    console.log(`Error adding contact: ${error}`);
    return c.json({ error: 'Failed to add contact' }, 500);
  }
});

// ==================== TRUST SCORE ROUTES ====================

// Calculate trust score for a contact
app.get("/make-server-f1d67aba/trust-score/:contactId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const contactId = c.req.param('contactId');
    const contact = await kv.get(`contact:${user.id}:${contactId}`);

    if (!contact) {
      return c.json({ error: 'Contact not found' }, 404);
    }

    // Trust score calculation based on parameters
    let trustScore = 0;
    const weights = {
      governmentVerified: 25,
      inContacts: 15,
      transactionHistory: 20,
      spamReports: -30,
      userRating: 20,
      connectionSource: 10,
      professionalVerification: 10,
    };

    // Government verification
    if (contact.governmentVerified) {
      trustScore += weights.governmentVerified;
    }

    // In contacts
    if (contact.inContacts) {
      trustScore += weights.inContacts;
    }

    // Transaction history (more transactions = higher trust)
    const txWeight = Math.min((contact.transactionCount / 10) * weights.transactionHistory, weights.transactionHistory);
    trustScore += txWeight;

    // Spam reports (reduces trust)
    trustScore += contact.spamReports * weights.spamReports;

    // User trust rating (0-100)
    trustScore += (contact.userTrustRating / 100) * weights.userRating;

    // Connection source reliability
    const reliableSources = ['LinkedIn', 'Workplace', 'Government Portal', 'Bank'];
    if (reliableSources.includes(contact.connectionSource)) {
      trustScore += weights.connectionSource;
    }

    // Normalize to 0-100
    trustScore = Math.max(0, Math.min(100, trustScore));

    const breakdown = {
      governmentVerified: contact.governmentVerified ? weights.governmentVerified : 0,
      inContacts: contact.inContacts ? weights.inContacts : 0,
      transactionHistory: txWeight,
      spamReports: contact.spamReports * weights.spamReports,
      userRating: (contact.userTrustRating / 100) * weights.userRating,
      connectionSource: reliableSources.includes(contact.connectionSource) ? weights.connectionSource : 0,
    };

    return c.json({ trustScore, breakdown, contact });
  } catch (error) {
    console.log(`Error calculating trust score: ${error}`);
    return c.json({ error: 'Failed to calculate trust score' }, 500);
  }
});

// Update user trust rating for a contact
app.put("/make-server-f1d67aba/contacts/:contactId/trust", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const contactId = c.req.param('contactId');
    const { userTrustRating } = await c.req.json();

    const contact = await kv.get(`contact:${user.id}:${contactId}`);
    if (!contact) {
      return c.json({ error: 'Contact not found' }, 404);
    }

    contact.userTrustRating = userTrustRating;
    await kv.set(`contact:${user.id}:${contactId}`, contact);

    return c.json({ contact });
  } catch (error) {
    console.log(`Error updating trust rating: ${error}`);
    return c.json({ error: 'Failed to update trust rating' }, 500);
  }
});

// ==================== TRANSACTION ROUTES ====================

// Get all transactions
app.get("/make-server-f1d67aba/transactions", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const transactions = await kv.getByPrefix(`transaction:${user.id}:`);
    return c.json({ transactions });
  } catch (error) {
    console.log(`Error fetching transactions: ${error}`);
    return c.json({ error: 'Failed to fetch transactions' }, 500);
  }
});

// Create a transaction (with trust verification)
app.post("/make-server-f1d67aba/transactions", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { contactId, amount, subAccountId, notes, isPriority } = await c.req.json();

    // Get contact and calculate trust score
    const contact = await kv.get(`contact:${user.id}:${contactId}`);
    if (!contact) {
      return c.json({ error: 'Contact not found' }, 404);
    }

    // Calculate trust score
    let trustScore = 0;
    if (contact.governmentVerified) trustScore += 25;
    if (contact.inContacts) trustScore += 15;
    trustScore += Math.min((contact.transactionCount / 10) * 20, 20);
    trustScore += contact.spamReports * -30;
    trustScore += (contact.userTrustRating / 100) * 20;
    trustScore = Math.max(0, Math.min(100, trustScore));

    // Block if trust level is below 20% (unless priority mode)
    if (trustScore < 20 && !isPriority) {
      return c.json({ 
        error: 'Transaction blocked: Trust level too low', 
        trustScore,
        minRequired: 20 
      }, 403);
    }

    // Get sub-account
    const subAccount = await kv.get(`subaccount:${user.id}:${subAccountId}`);
    if (!subAccount) {
      return c.json({ error: 'Sub-account not found' }, 404);
    }

    // Check balance
    if (subAccount.balance < amount) {
      return c.json({ error: 'Insufficient balance in sub-account' }, 400);
    }

    // Create transaction
    const txId = crypto.randomUUID();
    const transaction = {
      id: txId,
      userId: user.id,
      contactId,
      contactName: contact.contactName,
      amount,
      subAccountId,
      subAccountName: subAccount.name,
      trustScore,
      isPriority: isPriority || false,
      notes,
      status: 'completed',
      createdAt: new Date().toISOString(),
    };

    await kv.set(`transaction:${user.id}:${txId}`, transaction);

    // Update sub-account balance
    subAccount.balance -= amount;
    await kv.set(`subaccount:${user.id}:${subAccountId}`, subAccount);

    // Update contact transaction stats
    contact.transactionCount += 1;
    contact.totalTransactionValue += amount;
    await kv.set(`contact:${user.id}:${contactId}`, contact);

    return c.json({ transaction, newBalance: subAccount.balance });
  } catch (error) {
    console.log(`Error creating transaction: ${error}`);
    return c.json({ error: 'Failed to create transaction' }, 500);
  }
});

// ==================== SUB-ACCOUNT ROUTES ====================

// Get all sub-accounts
app.get("/make-server-f1d67aba/sub-accounts", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const subAccounts = await kv.getByPrefix(`subaccount:${user.id}:`);
    return c.json({ subAccounts });
  } catch (error) {
    console.log(`Error fetching sub-accounts: ${error}`);
    return c.json({ error: 'Failed to fetch sub-accounts' }, 500);
  }
});

// Create a new sub-account
app.post("/make-server-f1d67aba/sub-accounts", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { name, category, balance, limit, period } = await c.req.json();
    const accountId = crypto.randomUUID();

    const account = {
      id: accountId,
      userId: user.id,
      name,
      category,
      balance: balance || 0,
      limit: limit || 1000,
      period: period || 'monthly',
      createdAt: new Date().toISOString(),
    };

    await kv.set(`subaccount:${user.id}:${accountId}`, account);
    return c.json({ account });
  } catch (error) {
    console.log(`Error creating sub-account: ${error}`);
    return c.json({ error: 'Failed to create sub-account' }, 500);
  }
});

// Transfer between sub-accounts
app.post("/make-server-f1d67aba/sub-accounts/transfer", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { fromAccountId, toAccountId, amount } = await c.req.json();

    const fromAccount = await kv.get(`subaccount:${user.id}:${fromAccountId}`);
    const toAccount = await kv.get(`subaccount:${user.id}:${toAccountId}`);

    if (!fromAccount || !toAccount) {
      return c.json({ error: 'Account not found' }, 404);
    }

    if (fromAccount.balance < amount) {
      return c.json({ error: 'Insufficient balance' }, 400);
    }

    fromAccount.balance -= amount;
    toAccount.balance += amount;

    await kv.mset([
      { key: `subaccount:${user.id}:${fromAccountId}`, value: fromAccount },
      { key: `subaccount:${user.id}:${toAccountId}`, value: toAccount },
    ]);

    return c.json({ 
      success: true,
      fromAccount,
      toAccount
    });
  } catch (error) {
    console.log(`Error transferring between accounts: ${error}`);
    return c.json({ error: 'Failed to transfer' }, 500);
  }
});

// Add funds to sub-account
app.post("/make-server-f1d67aba/sub-accounts/:accountId/add-funds", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const accountId = c.req.param('accountId');
    const { amount } = await c.req.json();

    const account = await kv.get(`subaccount:${user.id}:${accountId}`);
    if (!account) {
      return c.json({ error: 'Account not found' }, 404);
    }

    account.balance += amount;
    await kv.set(`subaccount:${user.id}:${accountId}`, account);

    return c.json({ account });
  } catch (error) {
    console.log(`Error adding funds: ${error}`);
    return c.json({ error: 'Failed to add funds' }, 500);
  }
});

// ==================== ALERTS ROUTES ====================

// Get alerts for user
app.get("/make-server-f1d67aba/alerts", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const alerts = await kv.get(`alerts:${user.id}`) || [];
    return c.json({ alerts });
  } catch (error) {
    console.log(`Error fetching alerts: ${error}`);
    return c.json({ error: 'Failed to fetch alerts' }, 500);
  }
});

// Check system and create alerts
app.post("/make-server-f1d67aba/alerts/check", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const alerts = [];
    const subAccounts = await kv.getByPrefix(`subaccount:${user.id}:`);

    // Check for low balances
    for (const account of subAccounts) {
      if (account.balance < account.limit * 0.1) {
        alerts.push({
          id: crypto.randomUUID(),
          type: 'low_balance',
          severity: 'warning',
          message: `Low balance in ${account.name}: $${account.balance.toFixed(2)}`,
          accountId: account.id,
          createdAt: new Date().toISOString(),
        });
      }
    }

    await kv.set(`alerts:${user.id}`, alerts);
    return c.json({ alerts });
  } catch (error) {
    console.log(`Error checking alerts: ${error}`);
    return c.json({ error: 'Failed to check alerts' }, 500);
  }
});

Deno.serve(app.fetch);
